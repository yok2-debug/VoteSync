import { config } from 'dotenv';
config();

import '@/ai/flows/real-time-election-prediction.ts';