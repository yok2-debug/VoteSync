'use client';
import { useForm, useFieldArray, SubmitHandler, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import type { Election, Candidate, CommitteeMember } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Trash2, PlusCircle, Loader2, CalendarIcon } from 'lucide-react';
import { saveElection } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { format, setHours, setMinutes, getHours, getMinutes } from 'date-fns';

const committeeMemberSchema = z.object({
  name: z.string().min(1, 'Committee member name is required.'),
  role: z.enum(['Ketua', 'Anggota']),
});

const electionSchema = z.object({
  id: z.string(),
  name: z.string().min(3, 'Election name must be at least 3 characters.'),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  status: z.enum(['pending', 'active']),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  committee: z.array(committeeMemberSchema).optional(),
}).refine(data => {
    if (data.startDate && data.endDate) {
      return data.endDate > data.startDate;
    }
    return true;
}, {
    message: "End date and time must be after start date and time.",
    path: ["endDate"],
});

type ElectionFormData = z.infer<typeof electionSchema>;

interface ElectionFormProps {
  election: Omit<Election, 'allowedCategories' | 'allowedElections'>;
}

export function ElectionForm({ election }: ElectionFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ElectionFormData>({
    resolver: zodResolver(electionSchema),
    defaultValues: {
      ...election,
      status: election.status || 'pending',
      startDate: election.startDate ? new Date(election.startDate) : undefined,
      endDate: election.endDate ? new Date(election.endDate) : undefined,
      committee: election.committee || [],
    },
  });

  const { fields: committeeFields, append: appendCommittee, remove: removeCommittee } = useFieldArray({
    control: form.control,
    name: 'committee',
  });

  const onSubmit = async (data: ElectionFormData) => {
    setIsSubmitting(true);

    const formData = new FormData();
    formData.append('id', data.id);
    formData.append('name', data.name);
    formData.append('description', data.description);
    formData.append('status', data.status);
    if (data.startDate) {
        formData.append('startDate', data.startDate.toISOString());
    }
    if (data.endDate) {
        formData.append('endDate', data.endDate.toISOString());
    }
    formData.append('committee', JSON.stringify(data.committee || []));


    try {
      const result = await saveElection(formData);
      toast({
        title: `Election ${data.id === 'new' ? 'created' : 'updated'}`,
        description: `The election "${data.name}" has been saved successfully.`,
      });
      router.push('/admin/elections');
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error saving election',
        description: error instanceof Error ? error.message : 'An unknown error occurred.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
  const minutes = Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, '0'));

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Election Details</CardTitle>
            <CardDescription>Provide basic information about the election.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Election Name</Label>
              <Input id="name" {...form.register('name')} />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" {...form.register('description')} />
              {form.formState.errors.description && (
                <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                        <FormItem className="flex flex-col gap-2">
                        <FormLabel>Start Date & Time</FormLabel>
                        <div className="flex gap-2">
                           <Popover>
                                <PopoverTrigger asChild>
                                <FormControl>
                                    <Button
                                    variant={"outline"}
                                    className={cn(
                                        "w-full justify-start text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                    )}
                                    >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {field.value ? (
                                        format(field.value, "PPP")
                                    ) : (
                                        <span>Pick a date</span>
                                    )}
                                    </Button>
                                </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={(date) => {
                                        const current = field.value || new Date();
                                        const newDate = setMinutes(setHours(date || current, getHours(current)), getMinutes(current));
                                        field.onChange(newDate);
                                    }}
                                    initialFocus
                                />
                                </PopoverContent>
                            </Popover>
                        </div>
                         <div className="flex gap-2">
                               <Controller
                                name="startDate"
                                control={form.control}
                                render={({ field: timeField }) => (
                                    <Select
                                        value={timeField.value ? getHours(timeField.value).toString().padStart(2, '0') : '00'}
                                        onValueChange={(hour) => {
                                            const newDate = setHours(timeField.value || new Date(), parseInt(hour));
                                            timeField.onChange(newDate);
                                        }}
                                        disabled={!timeField.value}
                                    >
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {hours.map(h => <SelectItem key={h} value={h}>{h}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                                />
                               <Controller
                                name="startDate"
                                control={form.control}
                                render={({ field: timeField }) => (
                                    <Select
                                        value={timeField.value ? getMinutes(timeField.value).toString().padStart(2, '0') : '00'}
                                        onValueChange={(minute) => {
                                            const newDate = setMinutes(timeField.value || new Date(), parseInt(minute));
                                            timeField.onChange(newDate);
                                        }}
                                        disabled={!timeField.value}
                                    >
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {minutes.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                                />
                            </div>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                         <FormItem className="flex flex-col gap-2">
                        <FormLabel>End Date & Time</FormLabel>
                        <div className="flex gap-2">
                           <Popover>
                                <PopoverTrigger asChild>
                                <FormControl>
                                    <Button
                                    variant={"outline"}
                                    className={cn(
                                        "w-full justify-start text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                    )}
                                    >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {field.value ? (
                                        format(field.value, "PPP")
                                    ) : (
                                        <span>Pick a date</span>
                                    )}
                                    </Button>
                                </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                    mode="single"
                                    selected={field.value}
                                    onSelect={(date) => {
                                        const current = field.value || new Date();
                                        const newDate = setMinutes(setHours(date || current, getHours(current)), getMinutes(current));
                                        field.onChange(newDate);
                                    }}
                                    initialFocus
                                />
                                </PopoverContent>
                            </Popover>
                        </div>
                         <div className="flex gap-2">
                               <Controller
                                name="endDate"
                                control={form.control}
                                render={({ field: timeField }) => (
                                    <Select
                                        value={timeField.value ? getHours(timeField.value).toString().padStart(2, '0') : '00'}
                                        onValueChange={(hour) => {
                                            const newDate = setHours(timeField.value || new Date(), parseInt(hour));
                                            timeField.onChange(newDate);
                                        }}
                                        disabled={!timeField.value}
                                    >
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {hours.map(h => <SelectItem key={h} value={h}>{h}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                                />
                               <Controller
                                name="endDate"
                                control={form.control}
                                render={({ field: timeField }) => (
                                    <Select
                                        value={timeField.value ? getMinutes(timeField.value).toString().padStart(2, '0') : '00'}
                                        onValueChange={(minute) => {
                                            const newDate = setMinutes(timeField.value || new Date(), parseInt(minute));
                                            timeField.onChange(newDate);
                                        }}
                                        disabled={!timeField.value}
                                    >
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {minutes.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                                />
                            </div>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Controller
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="active">Active</SelectItem>
                          </SelectContent>
                      </Select>
                  )}
              />
              {form.formState.errors.status && (
                <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Election Committee</CardTitle>
            <CardDescription>Manage the committee members for this election.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {committeeFields.map((field, index) => (
              <div key={field.id} className="p-4 border rounded-lg relative space-y-4">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                  onClick={() => removeCommittee(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`committee.${index}.name`}>Member Name</Label>
                    <Input
                      id={`committee.${index}.name`}
                      {...form.register(`committee.${index}.name`)}
                    />
                    {form.formState.errors.committee?.[index]?.name && (
                      <p className="text-sm text-destructive">{form.formState.errors.committee?.[index]?.name?.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`committee.${index}.role`}>Role</Label>
                    <Controller
                      control={form.control}
                      name={`committee.${index}.role`}
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select role" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Ketua">Ketua</SelectItem>
                            <SelectItem value="Anggota">Anggota</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    />
                     {form.formState.errors.committee?.[index]?.role && (
                      <p className="text-sm text-destructive">{form.formState.errors.committee?.[index]?.role?.message}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={() => appendCommittee({ name: '', role: 'Anggota' })}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Committee Member
            </Button>
          </CardContent>
        </Card>
        
        <div className="flex justify-end gap-2">
           <Button type="button" variant="outline" onClick={() => router.push('/admin/elections')} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isSubmitting ? 'Saving...' : 'Save Election'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
